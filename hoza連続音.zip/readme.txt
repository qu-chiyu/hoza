Rules
- Free for personal and non-commercial use.
- Do not repost, repack,or use commercially.
- Do not train AI with this voicebank.